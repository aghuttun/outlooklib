from .outlooklib import *

__doc__ = outlooklib.__doc__
if hasattr(outlooklib, "__all__"):
    __all__ = outlooklib.__all__